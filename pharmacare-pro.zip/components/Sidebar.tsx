import React from 'react';
import { LayoutDashboard, Pill, ShoppingCart, Activity, Users, Truck, FileText, Settings, Sparkles } from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentPage, onNavigate }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'inventory', label: 'Médicaments', icon: Pill },
    { id: 'pos', label: 'Ventes / Caisse', icon: ShoppingCart },
    { id: 'prescriptions', label: 'Ordonnances', icon: FileText },
    { id: 'clients', label: 'Patients', icon: Users },
    { id: 'suppliers', label: 'Fournisseurs', icon: Truck },
    { id: 'reports', label: 'Rapports IA', icon: Activity },
    { id: 'settings', label: 'Paramètres', icon: Settings },
  ];

  return (
    <div className="w-64 bg-white h-screen shadow-lg flex flex-col fixed left-0 top-0 z-20 hidden md:flex">
      <div className="p-6 border-b border-gray-100 flex items-center gap-2">
        <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">
          P
        </div>
        <span className="text-xl font-bold text-slate-800">PharmaPro</span>
      </div>

      <nav className="flex-1 p-4 overflow-y-auto">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    isActive
                      ? 'bg-emerald-50 text-emerald-600 font-semibold shadow-sm ring-1 ring-emerald-100'
                      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                  }`}
                >
                  <Icon size={20} className={isActive ? 'text-emerald-600' : 'text-slate-400'} />
                  <span>{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-gray-100">
        <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles size={16} className="text-yellow-200" />
            <span className="font-semibold text-sm">Assistant IA</span>
          </div>
          <p className="text-xs text-emerald-50 mb-3 opacity-90">
            Besoin d'aide pour analyser vos stocks ?
          </p>
          <button 
            onClick={() => onNavigate('reports')}
            className="w-full bg-white/20 hover:bg-white/30 text-white text-xs py-2 rounded-lg transition-colors font-medium"
          >
            Ouvrir l'Assistant
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
